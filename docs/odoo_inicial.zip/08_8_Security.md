---
title: 8.8. Security
description: Desarrollando máodulos en Odoo. Seguridad
---
